
from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)
DB_NAME = 'bus_pass.db'

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            origin TEXT NOT NULL,
            destination TEXT NOT NULL,
            price REAL NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/book', methods=['POST'])
def book_ticket():
    data = request.json
    name = data.get('name')
    origin = data.get('origin')
    destination = data.get('destination')
    price = data.get('price')

    if not all([name, origin, destination, price]):
        return jsonify({'error': 'Incomplete details'}), 400

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO tickets (name, origin, destination, price) VALUES (?, ?, ?, ?)",
              (name, origin, destination, price))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Ticket booked successfully'}), 201

@app.route('/tickets', methods=['GET'])
def get_tickets():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM tickets")
    records = c.fetchall()
    conn.close()
    return jsonify(records)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
